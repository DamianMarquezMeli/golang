package domain

type Date struct {
	Day   int
	Month int
	Year  int
}
