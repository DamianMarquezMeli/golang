package main_test

import (
	"encoding/json"
	"fmt"
	"testing"

	skippa "github.com/devpablocristo/lively-video"
)

func TestGetCatFact(t *testing.T) {
	url := "https://catfact.ninja/fact"

	var catFact skippa.CatFact
	err := skippa.GetJson(url, &catFact)
	if err != nil {
		t.Errorf("Error gettung cat fact: %s", err.Error())
	} else {
		t.Logf("Cat fact: %s", catFact.Fact)
	}
}

func TestGetPortfolio(t *testing.T) {

	payload := `{
					"id": "DU5818706",
					"accountId": "DU5818706",
					"accountVan": "DU5818706",
					"accountTitle": "",
					"displayName": "DU5818706",
					"accountAlias": null,
					"accountStatus": 1657166400000,
					"currency": "USD",
					"type": "DEMO",
					"tradingType": "STKNOPT",
					"ibEntity": "IBLLC-US",
					"faclient": false,
					"clearingStatus": "O",
					"covestor": false,
					"parent": {
					"mmc": [],
					"accountId": "",
					"isMParent": false,
					"isMChild": false,
					"isMultiplex": false
				},
				"desc": "DU5818706"
			}`

	out, err := json.Marshal(payload)
	if err != nil {
		t.Errorf("Error: %v", err)
	}

	fmt.Println(string(out))

	fmt.Println(out)
	if err != nil {
		fmt.Println("Error marshalling:", err.Error())
	} else {
		fmt.Println("Marshalled:", string(out))
	}

}
