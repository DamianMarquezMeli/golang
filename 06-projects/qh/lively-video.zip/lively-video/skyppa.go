package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

var client *http.Client

type CatFact struct {
	Fact   string `json:"fact"`
	Length int    `json:"length"`
}

// type Stock string {
// 	Name:
// }

// type ParentPorfolio struct {
// 	Mmmc         []string `json:"mmc"`
// 	AccountId    string   `json:"accountId"`
// 	IsMParent    bool     `json:"isMParent"`
// 	IsMChildbool bool     `json:"isMChild"`
// 	IsMultiplex  bool     `json:"isMultiplex"`
// }

type ParentPorfolio struct {
	AccountID   string        `json:"accountId"`
	IsMChild    bool          `json:"isMChild"`
	IsMParent   bool          `json:"isMParent"`
	IsMultiplex bool          `json:"isMultiplex"`
	Mmc         []interface{} `json:"mmc"`
}

// type PortfolioAccount struct {
// 	Id             string         `json:"id"`
// 	AccountId      string         `json:"accountId"`
// 	AccountVan     string         `json:"accountVan"`
// 	AccountTitle   string         `json:"accountTitle"`
// 	DisplayName    string         `json:"displayName"`
// 	AccountAlias   string         `json:"accountAlias"`
// 	AccountStatus  int            `json:"accountStatus"`
// 	Currency       string         `json:"currency"`
// 	Type           string         `json:"type"`
// 	TradingType    string         `json:"tradingType"`
// 	IbEntity       string         `json:"ibEntity"`
// 	Faclient       bool           `json:"faclient"`
// 	ClearingStatus string         `json:"clearingStatus"`
// 	Covestor       bool           `json:"covestor"`
// 	Parent         ParentPorfolio `json:"parent"`
// 	Desc           string         `json:"desc"`
// }

type PortfolioAccount struct {
	AccountAlias   interface{}    `json:"accountAlias"`
	AccountID      string         `json:"accountId"`
	AccountStatus  int64          `json:"accountStatus"`
	AccountTitle   string         `json:"accountTitle"`
	AccountVan     string         `json:"accountVan"`
	ClearingStatus string         `json:"clearingStatus"`
	Covestor       bool           `json:"covestor"`
	Currency       string         `json:"currency"`
	Desc           string         `json:"desc"`
	DisplayName    string         `json:"displayName"`
	Faclient       bool           `json:"faclient"`
	IbEntity       string         `json:"ibEntity"`
	ID             string         `json:"id"`
	Parent         ParentPorfolio `json:"parent"`
	TradingType    string         `json:"tradingType"`
	Type           string         `json:"type"`
}

/*
{
  "AAPL": [
    {
      "name": "APPLE INC",
      "chineseName": "&#x82F9;&#x679C;&#x516C;&#x53F8;",
      "assetClass": "STK",
      "contracts": [
        {
          "conid": 265598,
          "exchange": "NASDAQ",
          "isUS": true
        },
        {
          "conid": 38708077,
          "exchange": "MEXI",
          "isUS": false
        },
        {
          "conid": 273982664,
          "exchange": "EBS",
          "isUS": false
        }
      ]
    },
    {
      "name": "LS 1X AAPL",
      "chineseName": null,
      "assetClass": "STK",
      "contracts": [
        {
          "conid": 493546048,
          "exchange": "LSEETF",
          "isUS": false
        }
      ]
    },
    {
      "name": "APPLE INC-CDR",
      "chineseName": "&#x82F9;&#x679C;&#x516C;&#x53F8;",
      "assetClass": "STK",
      "contracts": [
        {
          "conid": 532640894,
          "exchange": "AEQLIT",
          "isUS": false
        }
      ]
    }
  ],
  "WDC": [
    {
      "name": "WESTERN DIGITAL CORP",
      "chineseName": "&#x897F;&#x90E8;&#x6570;&#x636E;&#x516C;&#x53F8;",
      "assetClass": "STK",
      "contracts": [
        {
          "conid": 13681,
          "exchange": "NASDAQ",
          "isUS": true
        },
        {
          "conid": 75098745,
          "exchange": "FWB",
          "isUS": false
        },
        {
          "conid": 87880190,
          "exchange": "MEXI",
          "isUS": false
        }
      ]
    }
  ]
}

*/

func GetCatFact() {
	url := "https://catfact.ninja/fact"

	var catFact CatFact
	err := GetJson(url, &catFact)
	if err != nil {
		fmt.Println("Error gettung cat fact:", err.Error())
	} else {
		fmt.Println("Cat fact:", catFact.Fact)
	}

}

func GetPortfolio() {
	url := "https://localhost:5000/v1/api/portfolio/accounts"

	var ps []PortfolioAccount

	err := GetJson(url, ps)
	if err != nil {
		fmt.Println("Error gettung portfolio:", err.Error())
	} else {
		fmt.Println("Cat fact:", ps[0].AccountId)
	}
}

func GetJson(url string, target interface{}) error {
	resp, err := client.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	return json.NewDecoder(resp.Body).Decode(target)
}

func main() {
	client = &http.Client{Timeout: 10 * time.Second}

	GetCatFact()
	GetPortfolio()
}
