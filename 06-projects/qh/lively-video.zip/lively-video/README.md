# LivelyVideo

1. Check API:



curl -X POST [options] \
[URL]


curl -X POST [options] \
[URL]

-H "Content-Type: application/json" \



curl -X POST -F 'name=linuxize' -F 'email=linuxize@example.com' https://example.com/contact.php





curl -v -X POST \
-d  HTTP/1.1 \
-d Authorization: OAuth \
-d oauth_callback="oob", \
-d oauth_consumer_key="SKIPPATRD", \
-d oauth_nonce="fcbc9c08d69ac269f7f1", \
-d oauth_signature="nHp...AA%3D%3D", \
-d oauth_signature_method="RSA-SHA256", \
-d oauth_timestamp="1657545927", \
-d realm="limited_poa" \
-H Content-Length: 0 \
-H Host: localhost:12345 \
-H Connection: Keep-Alive \
-H User-Agent: Apache-HttpClient/4.5.1 (Java/1.8.0_102) \
-H Accept-Encoding: gzip,deflate \
https://www.interactivebrokers.com/tradingapi/v1/oauth/request_token



https://www.skippa.com/monies/api/v1/oauth2-cb/portfolio/accounts


example
curl -v\
  -H "Content-Type: application/json" \
  -H "X-Master-key: $2b$10$03Jv8kiV59itA7keIxbR2uNzBUFa9UE5X27PpGSUOEKVTKEIsMlBm" \
    https://api.jsonbin.io/v3/b



curl -v\
  -H "Content-Type: application/json" \
  -H "X-Master-key: SKIPPATRD" \
  https://www.skippa.com/monies/api/v1/oauth2-cb

  https://www.skippa.com/monies/api/v1/oauth2-cb?state=200


-H 'Authorization: Bearer <access_token>'



curl --user SKIPPATRD --data "grant_type=client_credentials“ https://www.skippa.com/monies/api/v1/oauth2-cb

curl --user <app_key>:<app_secret> --data "grant_type=client_credentials“ http://localhost:9876/learn/api/public/v1/oauth2/token







IBK account
devpablocristo@gmail.com
devpab805
_HaRRiF@rqjC58%

tucbox@gmail.com
tucbox123
_HaRRiF@rqjC58%


docker run --env IBEAM_ACCOUNT=tucbox123 --env IBEAM_PASSWORD=_HaRRiF@rqjC58% -p 5000:5000 voyz/ibeam



///////

metodo normal y correcto

bin/run.sh root/conf.yaml

tucbox@gmail.com
tucbox123
_HaRRiF@rqjC58%

hay que loggearse a la opagina tb y localmenete
en la pagina:

https://www.interactivebrokers.co.uk/portal/?action=ACCT_MGMT_MAIN&loginType=1&clt=0&RL=1&locale=en_US#/

con las mismas credenciale y decir desde ahi que se logee en un cartel

https://localhost:5000/v1/api/trsrv/stocks?symbols=AAPL,WDC



https://localhost:5000/v1/api/trsrv/stocks?symbols=AAPL,WDC


https://localhost:5000/v1/api/portfolio/accounts

https://www.skippa.com/monies/api/v1/oauth2-cb/portfolio/accounts


?code={authorization code}