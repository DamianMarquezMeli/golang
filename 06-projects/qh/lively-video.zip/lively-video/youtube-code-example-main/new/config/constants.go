package config

import (
	"golang.org/x/oauth2"
)

func SetupConfig() *oauth2.Config {
	return &oauth2.Config{
		ClientID:     "",
		ClientSecret: "",
		//Scopes:       []string{"https://www.googleapis.com/auth/userinfo.email"},
		//RedirectURL:  "http://localhost:8080/google/callback",
		//Endpoint:     google.Endpoint,
	}
}
