package main

import (
	"net/http"

	_ "fmt"
)

func main() {
	http.HandleFunc("/google/login", controller.GoogleLogin)
	http.HandleFunc("/google/callback", controller.GoogleCallback)

	http.ListenAndServe(":8080", nil)
}
