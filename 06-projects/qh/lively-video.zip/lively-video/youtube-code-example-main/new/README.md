1. Create config file


https://developers.google.com/identity/protocols/oauth2

API KEy: AIzaSyAgtSFE_OQmgksPbV_8x3-wDtGFvvjUc9g