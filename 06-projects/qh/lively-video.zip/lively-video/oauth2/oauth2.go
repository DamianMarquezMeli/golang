package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"

	"golang.org/x/oauth2"
	"golang.org/x/oauth2/github"
	"golang.org/x/oauth2/google"
)

// key is the github ID, value is user ID
var githubConnections map[string]string

// JSON Layout {"data ": {"viewer": {"id": "U123456789"}}}
type githubResponse struct {
	Data struct {
		Viewer struct {
			ID string `json:"id"`
		} `json:"viewer"`
	} `json:"data"`
}

var githubOauth2Config = &oauth2.Config{
	// get client id and secret from github
	// this all i need for github
	ClientID:     "944568975122-rva7lnbrf4jq3sb7glfe7algaierbgig.apps.googleusercontent.com",
	ClientSecret: "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"
	Endpoint:     github.Endpoint
}

func main() {
	http.HandleFunc("/", index)
	http.HandleFunc("/oauth2/github", startGithubOauth2)
	http.HandleFunc("/oauth2/github", completeGithubOauth2)

	http.ListenAndServe(":8080", nil)
}

func index(w http.ResponseWriter, r *http.Request) {

	fmt.Fprint(w, `<!DOCTYPE html>
	<html lang="en">
	<head>
	  <meta charset="UTF-8">
	  <title>OAuth2 Playground</title>
	</head>
		<form action="/oauth2/github" method="POST">
			<input type="submit" value="Login with Github">
		</form>
	</body>
	</html>`)
}

func startGithubOauth2(w http.ResponseWriter, r *http.Request) {
	redirect := githubOauth2Config.AuthCodeURL("0000")
	http.Redirect(w, r, redirect, http.StatusSeeOther)
}

func completeGithubOauth2(w http.ResponseWriter, r *http.Request) {
	code := r.FormValue("code")
	state := r.FormValue("state")

	if state != "0000" {
		http.Error(w, "State is incorrect", http.StatusBadRequest)
		return
	}

	token, err := githubOauth2Config.Exchange(r.Context(), code)
	if err != nil {
		http.Error(w, "Coud't login", http.StatusInternalServerError)
		return
	}

	ts := githubOauth2Config.TokenSource(r.Context(), token)
	client := oauth2.NewClient(r.Context(), ts)	

	requestBosy := strings.NewReader(`{"query": "query { viewer { id } }"}`)
	resp, err := client.POST("https://api.github.com/graphql", "application/json", requestBody)	
	if err != nil {
		http.Error(w, "Couldn't get user", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	// bs, err := ioutil.ReadAll(resp.Body)
	// if err != nil {
	// 	http.Error(w, "Couldn't read Github information	", http.StatusInternalServerError)
	// 	return
	// }

	// log.Println(string(bs)) // print the response body

	var gr githubResponse
	json.NewDecoder(resp.Body).Decode(&gr) 
	if err != nil {
		http.Error(w, "Github invalid response", http.StatusInternalServerError)
		return
	}

	githubID := gr.Data.Viewer.ID
	userID, ok := githubConnections[githubID]
	if !ok {
		http.Error(w, "User not found", http.StatusInternalServerError)
		return
	}
}
