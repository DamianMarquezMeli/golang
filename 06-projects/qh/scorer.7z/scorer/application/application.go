package application

func NewScorer() {

}
