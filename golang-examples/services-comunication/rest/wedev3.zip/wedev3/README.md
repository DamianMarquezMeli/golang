# This is the same bookstore app from the "2" directory
## Two updates are needed

### Update 1:

* Note: please ignore the commented code. 

1. Update "InventoryInfo".
2. List all the books.


### Update 2:

* Note: please uncomment the commented code. 

1. Update "addBooks".
2. Use this code to add more books to the bookstore: 
```
[
    {
        "book": {
            "author": {
                "firstname": "Frank",
                "lastname": "Herbert"
            },
            "title": "Dune",
            "price": 53.79,
            "isbn": "0340960191"
        },
        "stock": 5
    },
    {
        "book": {
            "author": {
                "firstname": "Isaac",
                "lastname": "Asimov"
            },
            "title": "Fundation",
            "price": 28.5,
            "isbn": "0-553-29335-4"
        },
        "stock": 1
    }
]
```