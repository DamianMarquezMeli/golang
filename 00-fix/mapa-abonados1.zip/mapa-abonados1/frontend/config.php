<?php

	/**
	 *	Dependecias:
	 *	Descripcion:
	 */
	header('Content-Type: text/html; charset=UTF-8'); 
	ini_set("display_errors", "On");
	error_reporting(E_ALL | E_STRICT);
 	header("Content-Type: text/html; charset=UTF-8");
 	date_default_timezone_set('America/Argentina/Tucuman');
 	setlocale(LC_ALL, 'es-AR');

 	require_once("/home/pablo/Proyectos/Web/PFW/pfw/php/config/config.php");
 	require_once("/home/pablo/Proyectos/Web/PFW/mapa_abonados/backend/php/funciones/funciones.php");

?>
