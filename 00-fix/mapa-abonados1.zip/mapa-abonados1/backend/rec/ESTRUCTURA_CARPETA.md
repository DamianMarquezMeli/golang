# Pantilla Estandar Proyecto

## Lista de recursos comunes

    aud: Archivos de audio.
    csv: Archivos separados por comas.
    des: Descargas.
    doc: Documentación.
    ftns: Fuentes.
    icn: Iconos.
    img: Imágenes.
    json: Archivos json.
    log: Logs varios.
    msc: Archivos misceláneos.
    sql: Archivos sql.
    sql/mysql: Archivos sql para MySQL.
    tmp: Archivos temporales.
    txt: Archivos de texto.
    vid: Videos.
    xml: Archivos xml.
