# LOG README

Para que se puede leer, escribir y crear el/los archivo/s de log
la carpeta debe tener permisos 777
