### Description

### Project Structure
The booking backend project has a flat structure:
```bash
├── Dockerfile
├── docker-compose.yml
├── internal
│   ├── api            # setup the router
│   ├── controller     # http handlers
│   ├── model          # the model
│   ├── repository     # interface to save orders and inventories
│   └── service        # services, the business logic
└── main.go         
```

### Endpoints
#### To handle the Inventory for the bookstore:
* [POST] - /api/v1/inventory
```bash
curl --location --request POST 'localhost:8080/api/v1/inventory' \
--header 'Content-Type: application/json' \
--data-raw ' {
    "author": {
        "first_name": "first name",
        "last_name": "last_name"
        },
    "book_title": "book1",
    "copies": 5
}'
```
* [PUT] - /api/v1/inventory
```bash
curl --location --request PUT 'localhost:8080/api/v1/inventory' \
--header 'Content-Type: application/json' \
--data-raw '{
    "id" : "inventory-3319090219",
    "book_title": "book1",
    "copies" : 1,
    "author": {
        "first_name": "first name",
        "last_name": "last name"
    }
}'
```
* [GET] - /api/v1/inventory/${inventory_id}
```bash
curl --location --request GET 'localhost:8080/api/v1/inventory/inventory-3319090219'
```
* [GET] - /api/v1/inventory
```bash
curl --location --request GET 'localhost:8080/api/v1/inventory'
```
* [DELETE] - /api/v1/inventoy
```bash
curl --location --request DELETE 'localhost:8080/api/v1/inventory' \
--header 'Content-Type: application/json' \
--data-raw '{
    "inventory_id" : "inventory-293000560"
}'
```

#### To handle the orders for the bookstore:

* [POST] - /api/v1/orders
```bash
curl --location --request POST 'localhost:8080/api/v1/orders' \
--header 'Content-Type: application/json' \
--data-raw '{
    "book_title" : "book1",
    "cant" : 2,
    "date" : "2021-11-26T16:04:05Z",
    "client": {
        "first_name": "Agustin",
        "last_name": "Saporiti"
    }
}'
```
* [PUT] - /api/v1/orders
```bash
curl --location --request PUT 'localhost:8080/api/v1/orders' \
--header 'Content-Type: application/json' \
--data-raw '{
    "id": "order-1799471257",
    "book_title" : "book1",
    "cant" : 3,
    "date" : "2021-11-26T16:04:05Z",
    "client": {
        "first_name": "Agustin",
        "last_name": "Saporiti"
    }
}'
```
* [GET] - /api/v1/orders

```bash
curl --location --request GET 'localhost:8080/api/v1/orders/'
```

* [GET] - /api/v1/orders/${order_id}
```bash
curl --location --request GET 'localhost:8080/api/v1/orders/order-1799471257'
```

* [DELETE] - /api/v1/orders
```bash
curl --location --request DELETE 'localhost:8080/api/v1/orders/' \
--header 'Content-Type: application/json' \
--data-raw '{
    "order_id": "order-1442635748"
}'
```

## Build and Running
First, you need to create docker image:
```bash
$ docker build -t order-service .
```
then, put to run the container...
```bash
$ docker run --name order-service -p 8080:8080 -t order-service
```

### Docker Compose
Another way to put to run the order service is using docker compose:
```bash
$ docker-compose build
$ docker-compose up 
```