package service

import "github.com/martinsaporiti/bookstore/order-service/internal/model"

type OrderService interface {
	Save(order *model.Order) (string, error)
	Update(order *model.Order) error
	Delete(orderId string) error
	Get(orderId string) (*model.Order, error)
	GetAll() ([]*model.Order, error)
}
