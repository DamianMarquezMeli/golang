package service

import (
	"errors"
	"testing"

	"github.com/martinsaporiti/bookstore/order-service/internal/mocks"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/assert"
)

func TestSaveNewInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("Save", inventoryToSave).Return(inventoryId, nil)

	// when
	inventoryId, err := invertoryService.Save(inventoryToSave)

	// then
	mock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.NotEmpty(t, inventoryId)
}

func TestUpdateInventory(t *testing.T) {
	// given
	inventoryId := "inventoryId"
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Id:        inventoryId,
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("Get", inventoryId).Return(inventoryToSave, nil)
	mock.On("Save", inventoryToSave).Return("", nil)

	// when
	err := invertoryService.Update(inventoryToSave)

	// then
	mock.AssertExpectations(t)
	assert.Nil(t, err)
}

func TestUpdateInventoryWithEmptyId(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Id:        "",
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	err := invertoryService.Update(inventoryToSave)

	// then
	mock.AssertNotCalled(t, "Get")
	mock.AssertNotCalled(t, "Save")
	assert.NotNil(t, err)
}

func TestUpdateInventoryWithEmptyBookTitle(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Id:        "inventoryId",
		Author:    author,
		BookTitle: "",
		Copies:    3,
	}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	err := invertoryService.Update(inventoryToSave)

	// then
	mock.AssertNotCalled(t, "Get")
	mock.AssertNotCalled(t, "Save")
	assert.NotNil(t, err)
}

func TestUpdateInventoryWithEmptyFirstNameClient(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "",
	}
	inventoryToSave := &model.Inventory{
		Id:        "inventoryId",
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	err := invertoryService.Update(inventoryToSave)

	// then
	mock.AssertNotCalled(t, "Get")
	mock.AssertNotCalled(t, "Save")
	assert.NotNil(t, err)
}

func TestUpdateInventoryWithEmptylastNameClient(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Id:        "inventoryId",
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	err := invertoryService.Update(inventoryToSave)

	// then
	mock.AssertNotCalled(t, "Get")
	mock.AssertNotCalled(t, "Save")
	assert.NotNil(t, err)
}

func TestSaveNewInventoryWithErrorEmptyBookTitle(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    -1,
	}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	inventoryId, err := invertoryService.Save(inventoryToSave)

	// then
	assert.NotNil(t, err)
	assert.Empty(t, inventoryId)
	mock.AssertNotCalled(t, "Save")
}

func TestSaveNewInventoryWithErrorCantLowerThanZero(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Author: author,
		Copies: 3,
	}
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	inventoryId, err := invertoryService.Save(inventoryToSave)

	// then
	assert.NotNil(t, err)
	assert.Empty(t, inventoryId)
	mock.AssertNotCalled(t, "Save")
}

func TestSaveNewInventoryWithErrorAuthorFirtNameEmpty(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	inventoryId, err := invertoryService.Save(inventoryToSave)

	// then
	assert.NotNil(t, err)
	assert.Empty(t, inventoryId)
	mock.AssertNotCalled(t, "Save")
}

func TestSaveNewInventoryWithErrorAuthorLastNameEmpty(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "",
	}
	inventoryToSave := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)

	// when
	inventoryId, err := invertoryService.Save(inventoryToSave)

	// then
	assert.NotNil(t, err)
	assert.Empty(t, inventoryId)
	mock.AssertNotCalled(t, "Save")
}

func TestGetInventoryWithErrorInventoryIdEmpty(t *testing.T) {
	// given
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("Get", "").Return(nil, errors.New(""))

	// when
	inventory, err := invertoryService.Get("")

	// then
	mock.AssertExpectations(t)
	assert.NotNil(t, err)
	assert.Nil(t, inventory)
}

func TestGetInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	expectdInventory := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("Get", inventoryId).Return(expectdInventory, nil)

	// when
	inventory, err := invertoryService.Get(inventoryId)

	// then
	mock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.Equal(t, expectdInventory, inventory)
}

func TestGetInventoryWhenInventoryDoesntExists(t *testing.T) {
	// given
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("Get", inventoryId).Return(nil, errors.New(""))

	// when
	_, err := invertoryService.Get(inventoryId)

	// then
	mock.AssertExpectations(t)
	assert.NotNil(t, err)
}

func TestGetAllInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	expectdInventory := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	expectdInventoryArr := []*model.Inventory{expectdInventory}
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("GetAll").Return(expectdInventoryArr, nil)

	// when
	inventoryArr, err := invertoryService.GetAll()

	// then
	mock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.Equal(t, expectdInventoryArr, inventoryArr)
}

func TestDeleteInventory(t *testing.T) {
	// given
	inventoryId := "inventoryId"
	mock := mocks.NewInventoryRepositoryMock()
	invertoryService := NewInventoryService(mock)
	mock.On("Delete", inventoryId).Return(nil)

	// when
	err := invertoryService.Delete(inventoryId)

	// then
	mock.AssertExpectations(t)
	assert.Nil(t, err)
}
