package service

import (
	"testing"
	"time"

	"github.com/martinsaporiti/bookstore/order-service/internal/mocks"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/assert"
)

func TestSaveNewOrder(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderToSave := &model.Order{
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      2,
	}

	orderId := "orderId"
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	inventoryServiceMock.On("GetCopiesFor", bookTitle).Return(5, nil)
	repostoryMock.On("Save", orderToSave).Return(orderId, nil)

	// when
	orderId, err = orderService.Save(orderToSave)

	// then
	inventoryServiceMock.AssertExpectations(t)
	repostoryMock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.NotEmpty(t, orderId)
}

func TestSaveNewOrderEmptyBookTitle(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	orderToSave := &model.Order{
		Client: client,
		Date:   date,
		Cant:   2,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	// when
	_, err = orderService.Save(orderToSave)

	// then
	assert.NotNil(t, err)
	repostoryMock.AssertNotCalled(t, "Save", orderToSave)
}

func TestSaveNewOrderWithCantFieldEqualZero(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderToSave := &model.Order{
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      0,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	// when
	_, err = orderService.Save(orderToSave)

	// then
	assert.NotNil(t, err)
	repostoryMock.AssertNotCalled(t, "Save", orderToSave)
}

func TestSaveNewOrderEmtyClientFirstName(t *testing.T) {
	// given
	client := model.Client{
		LastName: "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderToSave := &model.Order{
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      0,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	// when
	_, err = orderService.Save(orderToSave)

	// then
	assert.NotNil(t, err)
	repostoryMock.AssertNotCalled(t, "Save", orderToSave)
}

func TestSaveNewOrderEmtyClientLastName(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderToSave := &model.Order{
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      0,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	// when
	_, err = orderService.Save(orderToSave)

	// then
	assert.NotNil(t, err)
	repostoryMock.AssertNotCalled(t, "Save", orderToSave)
}

func TestSaveNewOrderWithNotEnoughCopies(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderToSave := &model.Order{
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      2,
	}

	orderId := "orderId"
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	inventoryServiceMock.On("GetCopiesFor", bookTitle).Return(1, nil)
	repostoryMock.On("Save", orderToSave).Return(orderId, nil)

	// when
	orderId, err = orderService.Save(orderToSave)

	// then
	inventoryServiceMock.AssertExpectations(t)
	assert.NotNil(t, err)
	repostoryMock.AssertNotCalled(t, "Save", orderToSave)
}

func TestUpdateExistingOrder(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderId := "orderId"

	orderToSave := &model.Order{
		Id:        orderId,
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      4,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	inventoryServiceMock.On("GetCopiesFor", bookTitle).Return(5, nil)
	repostoryMock.On("Get", orderId).Return(orderToSave, nil)
	repostoryMock.On("Save", orderToSave).Return(orderId, nil)

	// when
	err = orderService.Update(orderToSave)

	// then
	inventoryServiceMock.AssertExpectations(t)
	repostoryMock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.NotEmpty(t, orderId)
}

func TestUpdateExistingOrderWithNotEnoughCopies(t *testing.T) {
	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	orderId := "orderId"

	orderToSave := &model.Order{
		Id:        orderId,
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      6,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)

	inventoryServiceMock.On("GetCopiesFor", bookTitle).Return(5, nil)
	repostoryMock.On("Get", orderId).Return(orderToSave, nil)

	// when
	err = orderService.Update(orderToSave)

	// then
	inventoryServiceMock.AssertExpectations(t)
	assert.NotNil(t, err)
	repostoryMock.AssertNotCalled(t, "Save", orderToSave)
}

func TestDeleteOrder(t *testing.T) {
	// given
	orderId := "orderId"
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)
	repostoryMock.On("Delete", orderId).Return(nil)

	// when
	err := orderService.Delete(orderId)

	// then
	repostoryMock.AssertExpectations(t)
	assert.Nil(t, err)
}

func TestGetOrder(t *testing.T) {
	// given
	orderId := "orderId"
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	expectedOrder := &model.Order{
		Id:        orderId,
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      6,
	}
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)
	repostoryMock.On("Get", orderId).Return(expectedOrder, nil)

	// when
	order, err := orderService.Get(orderId)

	// then
	repostoryMock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.Equal(t, expectedOrder, order)
}

func TestGetAllOrders(t *testing.T) {
	// given
	orderId := "orderId"
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05Z"
	date, err := time.Parse(layout, str)

	bookTitle := "The Lord of the Rings"
	expectedOrder := &model.Order{
		Id:        orderId,
		Client:    client,
		Date:      date,
		BookTitle: bookTitle,
		Cant:      6,
	}
	expectedOrderArr := []*model.Order{expectedOrder}
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	repostoryMock := mocks.NewOrderRepositoryMock()
	orderService := NewOrderService(repostoryMock, inventoryServiceMock)
	repostoryMock.On("GetAll").Return(expectedOrderArr, nil)

	// when
	orderArrResult, err := orderService.GetAll()

	// then
	repostoryMock.AssertExpectations(t)
	assert.Nil(t, err)
	assert.Equal(t, expectedOrderArr, orderArrResult)
}
