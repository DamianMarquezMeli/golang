package service

import (
	"errors"

	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/martinsaporiti/bookstore/order-service/internal/repository"
)

type orderService struct {
	repo             repository.OrderRepository
	inventoryService InventoryService
}

func NewOrderService(repository repository.OrderRepository, inventoryService InventoryService) *orderService {
	return &orderService{
		repo:             repository,
		inventoryService: inventoryService,
	}
}

func (srv *orderService) Save(order *model.Order) (string, error) {
	if err := validateOrder(order); err != nil {
		return "", err
	}

	copies, err := srv.inventoryService.GetCopiesFor(order.BookTitle)

	if err != nil {
		return "", errors.New("Error getting book inventory")
	}

	if copies < order.Cant {
		return "", errors.New("Not enought copies to save the order")
	}

	return srv.repo.Save(order)
}

func (srv *orderService) Update(order *model.Order) error {
	orderToUpdate, err := srv.Get(order.Id)
	if err != nil || orderToUpdate == nil {
		return errors.New("Order id must not be null")
	}

	if err := validateOrder(order); err != nil {
		return err
	}

	copies, err := srv.inventoryService.GetCopiesFor(order.BookTitle)

	if err != nil {
		return errors.New("Error getting book inventory")
	}

	if copies < order.Cant {
		return errors.New("Not enought copies to save the order")
	}
	_, err = srv.Save(order)
	return err
}

func (srv *orderService) Delete(orderId string) error {
	return srv.repo.Delete(orderId)
}

func (srv *orderService) Get(orderId string) (*model.Order, error) {
	return srv.repo.Get(orderId)
}

func (srv *orderService) GetAll() ([]*model.Order, error) {
	return srv.repo.GetAll()
}

func validateOrder(order *model.Order) error {
	if order.BookTitle == "" {
		return errors.New("The book title must not be empty...")
	}
	if order.Cant < 1 {
		return errors.New("The Order must have more books to order")
	}

	if order.Client.FirstName == "" || order.Client.LastName == "" {
		return errors.New("The Order Client must have first name and last name")
	}
	return nil
}
