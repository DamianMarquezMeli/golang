package service

import "github.com/martinsaporiti/bookstore/order-service/internal/model"

type InventoryService interface {
	Save(inventory *model.Inventory) (string, error)
	Update(inventory *model.Inventory) error
	Delete(inventoryId string) error
	Get(inventoryId string) (*model.Inventory, error)
	GetAll() ([]*model.Inventory, error)
	GetCopiesFor(bookTitle string) (int, error)
}
