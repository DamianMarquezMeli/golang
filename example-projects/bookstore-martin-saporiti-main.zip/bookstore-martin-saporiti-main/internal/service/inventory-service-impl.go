package service

import (
	"errors"

	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/martinsaporiti/bookstore/order-service/internal/repository"
)

type inventoryService struct {
	repo repository.InventoryRepository
}

// Constructor
func NewInventoryService(repository repository.InventoryRepository) *inventoryService {
	return &inventoryService{
		repo: repository,
	}
}

// Validate and save a new inventory.
func (srv *inventoryService) Save(inventory *model.Inventory) (string, error) {
	if err := validateInventory(inventory); err != nil {
		return "", err
	}
	return srv.repo.Save(inventory)
}

// Validates and updates an existing inventory.
func (srv *inventoryService) Update(inventory *model.Inventory) error {
	if inventory.Id == "" {
		return errors.New("Inventory id not be null or empty")
	}

	if err := validateInventory(inventory); err != nil {
		return err
	}

	inventoryToUpdate, err := srv.Get(inventory.Id)
	if err != nil || inventoryToUpdate == nil {
		return errors.New("Inventory doesn't exist")
	}

	_, err = srv.Save(inventory)
	return err
}

// Deletes an inventory
func (srv *inventoryService) Delete(inventoryId string) error {
	return srv.repo.Delete(inventoryId)
}

// Returns the inventory with th inventory id received.
func (srv *inventoryService) Get(inventoryId string) (*model.Inventory, error) {
	return srv.repo.Get(inventoryId)
}

// Returns all the inventories.
func (srv *inventoryService) GetAll() ([]*model.Inventory, error) {
	return srv.repo.GetAll()
}

func (srv *inventoryService) GetCopiesFor(bookTitle string) (int, error) {
	inventory, err := srv.repo.GetByBookTitle(bookTitle)
	if err != nil {
		return 0, err
	}
	return int(inventory.Copies), nil
}

// Validates the inventory regarding their fields.
func validateInventory(inventory *model.Inventory) error {
	if inventory.BookTitle == "" {
		return errors.New("Book Title must not be empty")
	}

	if inventory.Copies < 0 {
		return errors.New("Book Copies must not be less than 0")
	}

	if inventory.Author.LastName == "" || inventory.Author.FirstName == "" {
		return errors.New("Book Author First Name and Last Name must not be emty")
	}
	return nil
}
