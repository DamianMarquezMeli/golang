package api

import (
	"github.com/gin-gonic/gin"
	"github.com/martinsaporiti/bookstore/order-service/internal/controller"
	"github.com/martinsaporiti/bookstore/order-service/internal/repository"
	"github.com/martinsaporiti/bookstore/order-service/internal/service"
)

var (
	inventoryRepository repository.InventoryRepository = repository.NewRedisInventoryRepository()
	inventoryService    service.InventoryService       = service.NewInventoryService(inventoryRepository)
	inventoryController controller.InventoryController = controller.NewInventoryController(inventoryService)

	orderRepository repository.OrderRepository = repository.NewRedisRepository()
	orderService    service.OrderService       = service.NewOrderService(orderRepository, inventoryService)
	orderController controller.OrderController = controller.NewOrderController(orderService)
)

func Setup() *gin.Engine {
	router := gin.Default()
	v1 := router.Group("/api/v1")
	{
		v1.POST("/orders", orderController.PostOrders)
		v1.PUT("/orders", orderController.UpdateOrders)
		v1.GET("/orders/:order", orderController.GetOrders)
		v1.GET("/orders/", orderController.GetOrders)
		v1.DELETE("/orders", orderController.DeleteOrders)

		v1.POST("/inventory", inventoryController.PostInventory)
		v1.PUT("/inventory", inventoryController.UpdateInventory)
		v1.GET("/inventory/:inventory", inventoryController.GetInventory)
		v1.GET("/inventory/", inventoryController.GetInventory)
		v1.DELETE("/inventory/", inventoryController.DeleteInventory)

	}
	router.NoRoute(func(c *gin.Context) {
		c.JSON(404, gin.H{"message": "Not found"})
	})
	return router
}
