package controller

import "github.com/gin-gonic/gin"

type InventoryController interface {
	PostInventory(c *gin.Context)
	UpdateInventory(c *gin.Context)
	GetInventory(c *gin.Context)
	DeleteInventory(c *gin.Context)
}
