package dto

type DeleteOrderDto struct {
	OrderId string `json:"order_id"`
}

type DeleteInventoryDto struct {
	IventoryId string `json:"inventory_id"`
}
