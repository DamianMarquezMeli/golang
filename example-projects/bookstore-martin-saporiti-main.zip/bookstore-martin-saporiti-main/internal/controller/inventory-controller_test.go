package controller

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/martinsaporiti/bookstore/order-service/internal/mocks"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/assert"
)

func TestSaveNewInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryId := "inventoryId"
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	inventoryController := NewInventoryController(inventoryServiceMock)
	inventoryServiceMock.On("Save", inventoryToSave).Return(inventoryId, nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.POST("/api/v1/inventory", inventoryController.PostInventory)
	var jsonStr = []byte(`{"author": {"first_name": "J. R. R.", "last_name": "Tolkien"}, "book_title": "The Lord of the Rings","copies": 3}`)
	req, err := http.NewRequest("POST", "/api/v1/inventory", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	inventoryServiceMock.AssertExpectations(t)
	assert.Equal(t, "{\"inventory_id\":\"inventoryId\"}", string(w.Body.Bytes()))
}

func TestUpdateExistingInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToUpdate := &model.Inventory{
		Id:        "inventoryId",
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}

	inventoryServiceMock := mocks.NewInventoryServiceMock()
	inventoryController := NewInventoryController(inventoryServiceMock)
	inventoryServiceMock.On("Update", inventoryToUpdate).Return(nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.PUT("/api/v1/inventory", inventoryController.UpdateInventory)
	var jsonStr = []byte(`{"author": {"first_name": "J. R. R.", "last_name": "Tolkien"}, "id" : "inventoryId", "book_title": "The Lord of the Rings","copies": 3}`)
	req, err := http.NewRequest("PUT", "/api/v1/inventory", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	inventoryServiceMock.AssertExpectations(t)
	assert.Equal(t, "{\"message\":\"Inventory Updated\"}", string(w.Body.Bytes()))
}

func TestSaveNewInventoryWithError(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	inventoryToSave := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	inventoryController := NewInventoryController(inventoryServiceMock)
	inventoryServiceMock.On("Save", inventoryToSave).Return("", errors.New(""))

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.POST("/api/v1/inventory", inventoryController.PostInventory)
	var jsonStr = []byte(`{"author": {"first_name": "J. R. R.", "last_name": "Tolkien"}, "book_title": "The Lord of the Rings","copies": 3}`)
	req, err := http.NewRequest("POST", "/api/v1/inventory", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 404, w.Code)
	inventoryServiceMock.AssertExpectations(t)
}

func TestGetInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	expectdInventory := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	inventoryId := "inventoryId"
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	inventoryController := NewInventoryController(inventoryServiceMock)
	inventoryServiceMock.On("Get", inventoryId).Return(expectdInventory, nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.GET("/api/v1/inventory/:inventory", inventoryController.GetInventory)
	req, err := http.NewRequest(http.MethodGet, "/api/v1/inventory/"+inventoryId, nil)
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	var inventory *model.Inventory
	json.Unmarshal(w.Body.Bytes(), &inventory)
	inventoryServiceMock.AssertExpectations(t)
	assert.Equal(t, expectdInventory, inventory)
}

func TestGetAllInventory(t *testing.T) {
	// given
	author := model.Author{
		FirstName: "J. R. R.",
		LastName:  "Tolkien",
	}
	expectdInventory := &model.Inventory{
		Author:    author,
		BookTitle: "The Lord of the Rings",
		Copies:    3,
	}
	expectdInventoryArr := []*model.Inventory{expectdInventory}
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	inventoryController := NewInventoryController(inventoryServiceMock)
	inventoryServiceMock.On("GetAll").Return(expectdInventoryArr, nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.GET("/api/v1/inventory", inventoryController.GetInventory)
	req, err := http.NewRequest(http.MethodGet, "/api/v1/inventory", nil)
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	var inventoryResultArr []*model.Inventory
	json.Unmarshal(w.Body.Bytes(), &inventoryResultArr)
	inventoryServiceMock.AssertExpectations(t)
	assert.Equal(t, expectdInventoryArr, inventoryResultArr)
}

func TestDeleteInventory(t *testing.T) {
	// given
	inventoryId := "inventoryId"
	inventoryServiceMock := mocks.NewInventoryServiceMock()
	inventoryController := NewInventoryController(inventoryServiceMock)
	inventoryServiceMock.On("Delete", inventoryId).Return(nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	var jsonStr = []byte(`{"inventory_id": "inventoryId"}`)
	r.DELETE("/api/v1/inventory", inventoryController.DeleteInventory)
	req, err := http.NewRequest(http.MethodDelete, "/api/v1/inventory", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	inventoryServiceMock.AssertExpectations(t)
}
