package controller

import "github.com/gin-gonic/gin"

type OrderController interface {
	PostOrders(c *gin.Context)
	UpdateOrders(c *gin.Context)
	GetOrders(c *gin.Context)
	DeleteOrders(c *gin.Context)
}
