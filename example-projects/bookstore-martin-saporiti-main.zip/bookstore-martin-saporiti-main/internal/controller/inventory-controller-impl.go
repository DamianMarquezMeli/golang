package controller

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/martinsaporiti/bookstore/order-service/internal/controller/dto"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/martinsaporiti/bookstore/order-service/internal/service"
)

type inventoryController struct {
	service service.InventoryService
}

func NewInventoryController(service service.InventoryService) *inventoryController {
	return &inventoryController{
		service,
	}
}

func (ctrl *inventoryController) PostInventory(c *gin.Context) {
	var inventory *model.Inventory
	if err := c.BindJSON(&inventory); err != nil {
		fmt.Println(err)
		c.JSON(404, gin.H{"message": "Error Saving the Inventory..."})
		return
	}

	inventoryId, err := ctrl.service.Save(inventory)
	if err != nil {
		c.JSON(404, gin.H{"message": "Error Saving the Inventory..." + err.Error()})
		return
	}

	c.JSON(200, gin.H{"inventory_id": inventoryId})
}

func (ctrl *inventoryController) UpdateInventory(c *gin.Context) {
	var inventory *model.Inventory
	if err := c.BindJSON(&inventory); err != nil {
		fmt.Println(err)
		c.JSON(404, gin.H{"message": "Error Saving the Inventory..."})
		return
	}

	err := ctrl.service.Update(inventory)
	if err != nil {
		fmt.Println("error:", err)
		c.JSON(404, gin.H{"message": "Error Updating the Inventory..." + err.Error()})
		return
	}
	c.JSON(200, gin.H{"message": "Inventory Updated"})
}

func (ctrl *inventoryController) DeleteInventory(c *gin.Context) {
	var inventoryToDelete dto.DeleteInventoryDto
	if err := c.BindJSON(&inventoryToDelete); err != nil {
		fmt.Println(err)
		c.JSON(404, gin.H{"message": "Error Deleting the Order..."})
		return
	}
	err := ctrl.service.Delete(inventoryToDelete.IventoryId)
	if err != nil {
		c.JSON(404, gin.H{"message": "Error Deleting the Order: " + inventoryToDelete.IventoryId})
	}
}

func (ctrl *inventoryController) GetInventory(c *gin.Context) {
	inventoryIdParam := c.Param("inventory")
	if inventoryIdParam == "" {
		getAllInventories(c, ctrl)
	} else {
		getInventory(c, ctrl, inventoryIdParam)
	}
}

func getAllInventories(c *gin.Context, ctrl *inventoryController) {
	inventories, err := ctrl.service.GetAll()
	if err != nil {
		fmt.Println("error:", err)
		c.JSON(404, gin.H{"message": "Error Retriving the Inventories..."})
		return
	}
	if len(inventories) == 0 {
		c.JSON(200, gin.H{"message": "There are not orders saved"})
		return
	}
	c.JSON(200, inventories)
}

func getInventory(c *gin.Context, ctrl *inventoryController, inventoryIdParam string) {
	inventory, err := ctrl.service.Get(inventoryIdParam)
	if err != nil {
		fmt.Println("error:", err)
		c.JSON(404, gin.H{"message": "Error Retriving the Inventory: " + inventoryIdParam})
		return
	}
	c.JSON(200, inventory)
}
