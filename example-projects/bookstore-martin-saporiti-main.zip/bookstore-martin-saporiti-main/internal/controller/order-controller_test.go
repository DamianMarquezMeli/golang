package controller

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/martinsaporiti/bookstore/order-service/internal/mocks"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/assert"
)

func getMockDate() time.Time {
	layout := "2006-01-02T15:04:05.00Z"
	str := "2006-01-02T16:04:05.00Z"
	date, _ := time.Parse(layout, str)
	return date
}
func TestSaveNewOrder(t *testing.T) {

	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	bookTitle := "The Lord of the Rings"
	orderToSave := &model.Order{
		Client:    client,
		Date:      getMockDate(),
		BookTitle: bookTitle,
		Cant:      2,
	}

	orderId := "orderId"
	mock := mocks.NewOrderServiceMock()
	orderController := NewOrderController(mock)
	mock.On("Save", orderToSave).Return(orderId, nil)
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.POST("/api/v1/orders", orderController.PostOrders)
	var jsonStr = []byte(`{
		"book_title" : "The Lord of the Rings",
		"cant" : 2,
		"date" : "2006-01-02T16:04:05Z",
		"client": {
			"first_name": "Froddo",
			"last_name": "Baggins"
		}
	}`)
	req, err := http.NewRequest("POST", "/api/v1/orders", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	mock.AssertExpectations(t)
	assert.Equal(t, "{\"order_id\":\"orderId\"}", string(w.Body.Bytes()))
}

func TestUpdateNewOrder(t *testing.T) {

	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	bookTitle := "The Lord of the Rings"
	orderToUpdate := &model.Order{
		Id:        "orderId",
		Client:    client,
		Date:      getMockDate(),
		BookTitle: bookTitle,
		Cant:      3,
	}

	mock := mocks.NewOrderServiceMock()
	orderController := NewOrderController(mock)
	mock.On("Update", orderToUpdate).Return(nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.PUT("/api/v1/orders", orderController.UpdateOrders)
	var jsonStr = []byte(`{
		"id" : "orderId",
		"book_title" : "The Lord of the Rings",
		"cant" : 3,
		"date" : "2006-01-02T16:04:05Z",
		"client": {
			"first_name": "Froddo",
			"last_name": "Baggins"
		}
	}`)

	req, err := http.NewRequest("PUT", "/api/v1/orders", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	mock.AssertExpectations(t)
	assert.Equal(t, "{\"message\":\"Order Updated\"}", string(w.Body.Bytes()))
}

func TestGetExistingOrder(t *testing.T) {

	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	orderId := "orderId"
	bookTitle := "The Lord of the Rings"
	expectedOrder := &model.Order{
		Id:        "orderId",
		Client:    client,
		Date:      getMockDate(),
		BookTitle: bookTitle,
		Cant:      3,
	}

	mock := mocks.NewOrderServiceMock()
	orderController := NewOrderController(mock)
	mock.On("Get", orderId).Return(expectedOrder, nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.GET("/api/v1/orders/:order", orderController.GetOrders)
	req, err := http.NewRequest("GET", "/api/v1/orders/"+orderId, nil)
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	var order *model.Order
	json.Unmarshal(w.Body.Bytes(), &order)
	mock.AssertExpectations(t)
	assert.Equal(t, expectedOrder, order)
}

func TestGetAllOrder(t *testing.T) {

	// given
	client := model.Client{
		FirstName: "Froddo",
		LastName:  "Baggins",
	}

	bookTitle := "The Lord of the Rings"
	expectedOrder := &model.Order{
		Id:        "orderId",
		Client:    client,
		Date:      getMockDate(),
		BookTitle: bookTitle,
		Cant:      3,
	}

	expectedOrderArr := []*model.Order{expectedOrder}
	mock := mocks.NewOrderServiceMock()
	orderController := NewOrderController(mock)
	mock.On("GetAll").Return(expectedOrderArr, nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.GET("/api/v1/orders", orderController.GetOrders)
	req, err := http.NewRequest("GET", "/api/v1/orders", nil)
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	var orderArr []*model.Order
	json.Unmarshal(w.Body.Bytes(), &orderArr)
	mock.AssertExpectations(t)
	assert.Equal(t, expectedOrderArr, orderArr)
}

func TestDeleteExistingOrder(t *testing.T) {

	// given
	orderId := "orderId"
	mock := mocks.NewOrderServiceMock()
	orderController := NewOrderController(mock)
	mock.On("Delete", orderId).Return(nil)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.DELETE("/api/v1/orders", orderController.DeleteOrders)
	var jsonStr = []byte(`{"order_id": "orderId"}`)
	req, err := http.NewRequest("DELETE", "/api/v1/orders", bytes.NewBuffer(jsonStr))
	if err != nil {
		panic(err)
	}

	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	// when
	r.ServeHTTP(w, req)

	// then
	assert.Equal(t, 200, w.Code)
	mock.AssertExpectations(t)
}
