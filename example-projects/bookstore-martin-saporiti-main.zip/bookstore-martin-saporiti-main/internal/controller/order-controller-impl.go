package controller

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/martinsaporiti/bookstore/order-service/internal/controller/dto"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/martinsaporiti/bookstore/order-service/internal/service"
)

type orderController struct {
	srv service.OrderService
}

func NewOrderController(srv service.OrderService) *orderController {
	return &orderController{
		srv,
	}
}

func (ctrl *orderController) PostOrders(c *gin.Context) {
	var order *model.Order
	if err := c.BindJSON(&order); err != nil {
		fmt.Println(err)
		c.JSON(404, gin.H{"message": "Error Saving the Order..."})
		return
	}

	orderId, err := ctrl.srv.Save(order)

	if err != nil {
		fmt.Println("error:", err)
		c.JSON(404, gin.H{"message": "Error Saving the Order..." + err.Error()})
		return
	}

	c.JSON(200, gin.H{"order_id": orderId})
}

func (ctrl *orderController) UpdateOrders(c *gin.Context) {
	var order *model.Order
	if err := c.BindJSON(&order); err != nil {
		fmt.Println(err)
		c.JSON(404, gin.H{"message": "Error Updating the Order..."})
		return
	}

	if err := ctrl.srv.Update(order); err != nil {
		c.JSON(404, gin.H{"message": "Error Updating the Order..." + err.Error()})
		return
	}

	c.JSON(200, gin.H{"message": "Order Updated"})
}

func (ctrl *orderController) GetOrders(c *gin.Context) {
	orderIdParam := c.Param("order")
	if orderIdParam == "" {
		getAll(c, ctrl)
	} else {
		get(c, ctrl, orderIdParam)
	}
}

func (ctrl *orderController) DeleteOrders(c *gin.Context) {
	var orderToDelete dto.DeleteOrderDto
	if err := c.BindJSON(&orderToDelete); err != nil {
		fmt.Println(err)
		c.JSON(404, gin.H{"message": "Error Deleting the Order..."})
		return
	}
	err := ctrl.srv.Delete(orderToDelete.OrderId)
	if err != nil {
		c.JSON(404, gin.H{"message": "Error Deleting the Order: " + orderToDelete.OrderId})
	}
}

func getAll(c *gin.Context, ctrl *orderController) {
	orders, err := ctrl.srv.GetAll()
	if err != nil {
		fmt.Println("error:", err)
		c.JSON(404, gin.H{"message": "Error Retriving the Orders..."})
		return
	}
	if len(orders) == 0 {
		c.JSON(200, gin.H{"message": "There are not orders saved"})
		return
	}
	c.JSON(200, orders)
}

func get(c *gin.Context, ctrl *orderController, orderId string) {
	order, err := ctrl.srv.Get(orderId)
	if err != nil {
		fmt.Println("error:", err)
		c.JSON(404, gin.H{"message": "Error Retriving the Order: " + orderId})
		return
	}
	c.JSON(200, order)
}
