package model

import "time"

type Client struct {
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
}

type Order struct {
	Id        string    `json:"id"`
	Client    Client    `json:"client"`
	BookTitle string    `json:"book_title"`
	Cant      int       `json:"cant"`
	Date      time.Time `json:"date" time_format:"2006-01-02T15:04:05"`
}
