package model

type Author struct {
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
}

type Inventory struct {
	Id        string `json:"id"`
	Author    Author `json:"author"`
	BookTitle string `json:"book_title"`
	Copies    int8   `json:"copies"`
}
