package mocks

import (
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/mock"
)

type MockInventoryRepository struct {
	mock.Mock
}

func NewInventoryRepositoryMock() *MockInventoryRepository {
	return &MockInventoryRepository{}
}

func (mock *MockInventoryRepository) Save(inventory *model.Inventory) (string, error) {
	args := mock.Called(inventory)
	return args[0].(string), args.Error(1)
}

func (mock *MockInventoryRepository) Delete(inventoryId string) error {
	args := mock.Called(inventoryId)
	return args.Error(0)
}

func (mock *MockInventoryRepository) Get(inventoryId string) (*model.Inventory, error) {
	args := mock.Called(inventoryId)
	if args[0] != nil {
		return args[0].(*model.Inventory), args.Error(1)
	} else {
		return nil, args.Error(1)
	}
}

func (mock *MockInventoryRepository) GetByBookTitle(bookTitle string) (*model.Inventory, error) {
	args := mock.Called(bookTitle)
	if args[0] != nil {
		return args[0].(*model.Inventory), args.Error(1)
	} else {
		return nil, args.Error(1)
	}
}

func (mock *MockInventoryRepository) GetAll() ([]*model.Inventory, error) {
	args := mock.Called()
	return args[0].([]*model.Inventory), args.Error(1)
}

type MockOrderRepository struct {
	mock.Mock
}

func NewOrderRepositoryMock() *MockOrderRepository {
	return &MockOrderRepository{}
}

func (orm *MockOrderRepository) Save(order *model.Order) (string, error) {
	args := orm.Called(order)
	return args[0].(string), args.Error(1)
}

func (orm *MockOrderRepository) Delete(orderKey string) error {
	args := orm.Called(orderKey)
	return args.Error(0)
}

func (orm *MockOrderRepository) Get(orderKey string) (*model.Order, error) {
	args := orm.Called(orderKey)
	if args[0] != nil {
		return args[0].(*model.Order), args.Error(1)
	} else {
		return nil, args.Error(1)
	}
}

func (orm *MockOrderRepository) GetAll() ([]*model.Order, error) {
	args := orm.Called()
	return args[0].([]*model.Order), args.Error(1)
}
