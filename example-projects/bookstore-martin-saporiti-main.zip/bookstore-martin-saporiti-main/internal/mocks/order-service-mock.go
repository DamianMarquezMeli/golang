package mocks

import (
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/mock"
)

type MockOrderService struct {
	mock.Mock
}

func NewOrderServiceMock() *MockOrderService {
	return &MockOrderService{}
}

func (mock *MockOrderService) Save(order *model.Order) (string, error) {
	args := mock.Called(order)
	return args[0].(string), args.Error(1)
}

func (mock *MockOrderService) Update(order *model.Order) error {
	args := mock.Called(order)
	return args.Error(0)
}

func (mock *MockOrderService) Delete(orderId string) error {
	args := mock.Called(orderId)
	return args.Error(0)
}

func (mock *MockOrderService) Get(orderId string) (*model.Order, error) {
	args := mock.Called(orderId)
	if args[0] != "" {
		return args[0].(*model.Order), args.Error(1)
	} else {
		return nil, args.Error(1)
	}
}

func (mock *MockOrderService) GetAll() ([]*model.Order, error) {
	args := mock.Called()
	return args[0].([]*model.Order), args.Error(1)
}
