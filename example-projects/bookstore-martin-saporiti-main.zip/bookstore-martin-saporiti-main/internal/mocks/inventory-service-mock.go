package mocks

import (
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
	"github.com/stretchr/testify/mock"
)

type MockInventoryService struct {
	mock.Mock
}

func NewInventoryServiceMock() *MockInventoryService {
	return &MockInventoryService{}
}

func (mock *MockInventoryService) Save(inventory *model.Inventory) (string, error) {
	args := mock.Called(inventory)
	return args[0].(string), args.Error(1)
}

func (mock *MockInventoryService) Update(inventory *model.Inventory) error {
	args := mock.Called(inventory)
	return args.Error(0)
}

func (mock *MockInventoryService) Delete(inventoryId string) error {
	args := mock.Called(inventoryId)
	return args.Error(0)
}

func (mock *MockInventoryService) Get(inventoryId string) (*model.Inventory, error) {
	args := mock.Called(inventoryId)
	if args[0] != "" {
		return args[0].(*model.Inventory), args.Error(1)
	} else {
		return nil, args.Error(1)
	}
}

func (mock *MockInventoryService) GetAll() ([]*model.Inventory, error) {
	args := mock.Called()
	return args[0].([]*model.Inventory), args.Error(1)
}

func (mock *MockInventoryService) GetCopiesFor(bookTitle string) (int, error) {
	args := mock.Called(bookTitle)
	return args[0].(int), args.Error(1)
}
