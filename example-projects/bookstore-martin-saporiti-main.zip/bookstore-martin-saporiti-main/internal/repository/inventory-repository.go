package repository

import "github.com/martinsaporiti/bookstore/order-service/internal/model"

const (
	inventoryPrefix string = "inventory-"
)

type InventoryRepository interface {
	Save(inventory *model.Inventory) (string, error)
	Delete(bookTitle string) error
	Get(bookTitle string) (*model.Inventory, error)
	GetByBookTitle(bookTitle string) (*model.Inventory, error)
	GetAll() ([]*model.Inventory, error)
}
