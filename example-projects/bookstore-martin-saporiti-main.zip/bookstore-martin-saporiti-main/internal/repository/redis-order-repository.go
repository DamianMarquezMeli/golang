package repository

import (
	"encoding/json"
	"hash/fnv"
	"os"
	"strconv"

	"github.com/go-redis/redis"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
)

type redisRepository struct {
	client *redis.Client
}

func NewRedisRepository() *redisRepository {

	host := os.Getenv("REDIS-HOST")
	port := os.Getenv("REDIS-PORT")

	if host == "" {
		host = "localhost"
	}

	if port == "" {
		port = "6379"
	}
	return &redisRepository{
		client: redis.NewClient(&redis.Options{
			Addr:     host + ":" + port,
			Password: "",
			DB:       0,
		}),
	}
}

func getOrderKey(order *model.Order) string {
	h := fnv.New32a()
	h.Write([]byte(order.BookTitle + "-" + order.Client.LastName + order.Date.String()))
	return orderPrefix + strconv.Itoa(int(h.Sum32()))
}

func (r *redisRepository) Save(order *model.Order) (string, error) {
	if order.Id == "" {
		order.Id = getOrderKey(order)
	}
	result, err := json.Marshal(order)
	if err != nil {
		return "", err
	}
	err = r.client.Set(order.Id, result, 0).Err()
	if err != nil {
		return "", err
	}
	return order.Id, err
}

func (r *redisRepository) Delete(orderKey string) error {
	return r.client.Del(orderKey).Err()
}

func (r *redisRepository) Get(orderKey string) (*model.Order, error) {
	value, err := r.client.Get(orderKey).Result()
	if err != nil {
		return &model.Order{}, err
	}

	var order *model.Order
	json.Unmarshal([]byte(value), &order)
	return order, nil
}

func (r *redisRepository) GetAll() ([]*model.Order, error) {
	cmd := r.client.Keys(orderPrefix + "*")
	var result []*model.Order
	for _, key := range cmd.Val() {
		order, _ := r.Get(key)
		result = append(result, order)
	}
	return result, nil
}
