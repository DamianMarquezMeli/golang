package repository

import (
	"encoding/json"
	"hash/fnv"
	"os"
	"strconv"

	"github.com/go-redis/redis"
	"github.com/martinsaporiti/bookstore/order-service/internal/model"
)

type redisInventoryRepository struct {
	client *redis.Client
}

func NewRedisInventoryRepository() *redisInventoryRepository {

	host := os.Getenv("REDIS-HOST")
	port := os.Getenv("REDIS-PORT")

	if host == "" {
		host = "localhost"
	}

	if port == "" {
		port = "6379"
	}

	return &redisInventoryRepository{
		client: redis.NewClient(&redis.Options{
			Addr:     host + ":" + port,
			Password: "",
			DB:       0,
		}),
	}
}

func getInventoryKey(bookTitle string) string {
	h := fnv.New32a()
	h.Write([]byte(bookTitle))
	return inventoryPrefix + strconv.Itoa(int(h.Sum32()))
}

func (r *redisInventoryRepository) Save(inventory *model.Inventory) (string, error) {
	if inventory.Id == "" {
		inventory.Id = getInventoryKey(inventory.BookTitle)
	}
	result, err := json.Marshal(inventory)
	if err != nil {
		return "", err
	}
	err = r.client.Set(inventory.Id, result, 0).Err()
	if err != nil {
		return "", err
	}
	return inventory.Id, nil
}

func (r *redisInventoryRepository) Delete(inventoryId string) error {
	return r.client.Del(inventoryId).Err()
}

func (r *redisInventoryRepository) Get(inventoryId string) (*model.Inventory, error) {
	inv, err := r.client.Get(inventoryId).Result()
	if err != nil {
		return &model.Inventory{}, err
	}

	var inventory *model.Inventory
	json.Unmarshal([]byte(inv), &inventory)
	return inventory, nil
}

func (r *redisInventoryRepository) GetByBookTitle(bookTitle string) (*model.Inventory, error) {
	return r.Get(getInventoryKey(bookTitle))
}

func (r *redisInventoryRepository) GetAll() ([]*model.Inventory, error) {
	cmd := r.client.Keys(inventoryPrefix + "*")
	var result []*model.Inventory
	for _, key := range cmd.Val() {
		inv, _ := r.Get(key)
		result = append(result, inv)
	}
	return result, nil
}
