package repository

import "github.com/martinsaporiti/bookstore/order-service/internal/model"

const (
	orderPrefix string = "order-"
)

type OrderRepository interface {
	Save(order *model.Order) (string, error)
	Delete(orderKey string) error
	Get(orderKey string) (*model.Order, error)
	GetAll() ([]*model.Order, error)
}
