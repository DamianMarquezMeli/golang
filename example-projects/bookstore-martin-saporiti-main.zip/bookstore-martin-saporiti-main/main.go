package main

import (
	"github.com/martinsaporiti/bookstore/order-service/internal/api"
)

func main() {
	api.Setup().Run()
}
