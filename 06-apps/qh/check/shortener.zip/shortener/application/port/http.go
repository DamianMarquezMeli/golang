package port

type HttpHandler interface {
	SetupRoutes()
	Run(addres string)
}
