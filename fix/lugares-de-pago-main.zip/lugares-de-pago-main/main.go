package main

import (
	"fmt"

	csv "github.com/devpablocristo/lugares-de-pago/ccc-csv"
)

func main() {

	lpv := csv.CargarCsv("viejos")
	lpn := csv.CargarCsv("nuevos")

	fmt.Println("Eliminar:")
	elim := restaDeSlices(lpv, lpn)
	for i := 0; i < len(elim); i++ {
		fmt.Println(elim[i].Direccion, "-", elim[i].Localidad)

	}

	fmt.Println("---------------------------------------")

	fmt.Println("Agregar:")
	agre := restaDeSlices(lpn, lpv)
	for i := 0; i < len(agre); i++ {
		fmt.Println(agre[i].Direccion, "-", agre[i].Localidad)

	}
}

// encuentra los que elementos que solo están en slice1
func restaDeSlices(slice1 csv.LugaresDePago, slice2 csv.LugaresDePago) csv.LugaresDePago {
	var diff csv.LugaresDePago
	for _, s1 := range slice1 {
		found := false
		for _, s2 := range slice2 {
			if s1.Comp == s2.Comp {
				found = true
				break
			}
		}
		// String not found. We add it to return slice
		if !found {
			diff = append(diff, s1)
		}
	}
	return diff
}
