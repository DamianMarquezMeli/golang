Common features.
