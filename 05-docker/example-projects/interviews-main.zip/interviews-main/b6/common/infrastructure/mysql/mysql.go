package mysqlcmn
