ya le saque todos los punteros y sigue el error, no se porque.

DDD
TDD
BDD

Clean Arch

Patterns:
DIP
Concurrence
