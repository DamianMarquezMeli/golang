package controllers

type ErrorResponse struct {
	Message string `json:"message"`
}
