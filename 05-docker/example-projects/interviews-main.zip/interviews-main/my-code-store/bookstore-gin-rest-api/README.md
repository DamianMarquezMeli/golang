{
    "username":"toribio.gato",
    "password":"12345",
    "email":"tori@gmail.com"
}

En service se hace todo cq cuestion logica calculos o lo sea

repository interactua con la base de datos, o con los elementos de consulta, recibe todo procesado desde service


main->app->