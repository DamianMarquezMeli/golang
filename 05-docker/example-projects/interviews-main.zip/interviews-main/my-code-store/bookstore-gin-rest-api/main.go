package main

import (
	"github.com/devpablocristo/interviews/bookstore-gin-rest-api/app"
)

func main() {
	app.StartApp()
}
