package main

import (
	"main/homepage/infrastructure/api"
)

func main() {
	api.HandleRequests()
}
