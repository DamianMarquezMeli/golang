


Orders
{
    "client": {
        "firstname": "Homero",
        "lastname": "Simpson"
    },
    "date": "2021-11-29T09:55:34.854041217-03:00",
    "quantity": 51,
    "books": {
        book[]
        "author": {
            "firstname": "Isaac",
            "lastname": "Asimov"
        },
        "title": "Fundation",
        "price": 28.5,
        "isbn": "0-553-29335-4"
    }
}

{
    "client": {
        "firstname": "Juan",
        "lastname": "Perez"
    },
    "date": "2021-11-30T10:40:54.412167134-03:00",
    "details": [
        {
            "books": {
                "author": {
                    "firstname": "Isaac",
                    "lastname": "Asimov"
                },
                "title": "Fundation",
                "price": 28.5,
                "isbn": "0-553-29335-4"
            },
            "quantity": 1
        },
        {
            "books": {
                "author": {
                    "firstname": "Stanislaw",
                    "lastname": "Lem"
                },
                "title": "Solaris",
                "price": 65.2,
                "isbn": "0156027607"
            },
            "quantity": 42
        }
    ]
}


Inventory

{
    "book": {
        "author": {
            "firstname": "Gabriel",
            "lastname": "Garcia Marquez"
        },
        "title": "100 años de soledad",
        "isbn": "0060929790,
        "price": 97.00,

    },
    "stock": 31
}

{
    "book": {
        "author": {
            "firstname": "Frank",
            "lastname": "Herbert"
        },
        "title": "Dune",
        "price": 53.79,
        "isbn": "0340960191"
    },
    "stock": 12
}

{
    "book": {
        "author": {
            "firstname": "Isaac",
            "lastname": "Asimov"
        },
        "title": "Fundation",
        "price": 28.5,
        "isbn": "0-553-29335-4"
    },
    "stock": 41
}